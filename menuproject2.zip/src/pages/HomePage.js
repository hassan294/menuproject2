import RestaurantWebsite from "../components/RestaurantWebsite.copy";

const HomePage = () => {
  return (
    <div>
      <RestaurantWebsite />
    </div>
  );
};

export default HomePage;
