import HomePage from "./pages/HomePage";
import "./styles/styles.css";

function App() {
  return (
    <div className="App">
      <HomePage />
    </div>
  );
}

export default App;
